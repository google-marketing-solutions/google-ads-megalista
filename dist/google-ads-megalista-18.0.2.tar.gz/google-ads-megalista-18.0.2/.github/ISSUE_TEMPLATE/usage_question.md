---
name: Library-specific Usage Question
about: Ask a question about this library that is neither a bug report nor feature request.
title: ''
labels: question
assignees: ''

---
<!-- PLEASE READ
This form is for usage questions specific to this library.

For questions that are related to the Google Ads API itself and not specific to this library, please reach out to one of our support channels: https://developers.google.com/google-ads/api/support. 

For troubleshooting tips, see: https://developers.google.com/google-ads/api/docs/best-practices/troubleshooting
-->

**What is your question?**

